package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.exception.CustomerNotFoundException;
import com.ltimindtree.service.impl.CustomerServiceImpl;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	private CustomerServiceImpl customerImpl;
	
	private Map<String, Object> response;
	
	//localhost:8080/customers/registerCustomer
	@PostMapping("/registerCustomer")
	public ResponseEntity<Map<String, Object>>  customerRegistration(@RequestBody Customer customer){
		response=new HashMap<String, Object>();
		response.put("message", "Customer Registered successfully");
		response.put("status",HttpStatus.OK);
		response.put("body", customerImpl.saveCustomer(customer));
		response.put("error",false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
	
	//localhost:8080/customers/customerUpdate/{id}
	@PutMapping("/customerUpdate/{id}")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer, @PathVariable(value = "id") int id) throws CustomerNotFoundException{
		Customer updateCustomer=customerImpl.updateCustomer(customer, id);
		if(updateCustomer==null) {
			return new ResponseEntity<Customer>(HttpStatus.INTERNAL_SERVER_ERROR);  
		}
		return new ResponseEntity<Customer>(updateCustomer, HttpStatus.OK);
	}
	
	//localhost:8080/customers/
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deactivateCustomer(@PathVariable int id) throws CustomerNotFoundException{
		customerImpl.deleteCustomer(id);
		return new ResponseEntity<String>("Customer Deleted Successfully",HttpStatus.OK);
	}

}
