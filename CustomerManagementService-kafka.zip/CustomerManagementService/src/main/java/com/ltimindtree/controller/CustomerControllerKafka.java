package com.ltimindtree.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Customer;
import com.ltimindtree.entity.CustomerEvent;
import com.ltimindtree.service.impl.CustomerProducer;

@RestController
@RequestMapping("/api/v1")
public class CustomerControllerKafka {
	
	//@Autowired
	private CustomerProducer custPod;
	
	
	public CustomerControllerKafka(CustomerProducer custPod) {
		super();
		this.custPod = custPod;
	}




	@PostMapping("/customers")
	public String placeOrder(@RequestBody Customer customer) {
		//customer.setCustomerId(UUID.randomUUID().toString());
		//customer.setId(UUID.randomUUID());
		
		CustomerEvent customerEvent=new CustomerEvent();
		customerEvent.setStatus("Pending");
		customerEvent.setMessage("Customer status is in pending state");
		customerEvent.setCustomer(customer);
		custPod.sendMessage(customerEvent);
		return "Customer data fetch Successfully";
	}


}
